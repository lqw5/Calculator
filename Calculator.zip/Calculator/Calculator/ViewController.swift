///Users/laurenwong/Documents/Calculator/Calculator/Base.lproj/Main.storyboard
//  ViewController.swift
//  Calculator
//
//  Created by Lauren Wong on 8/26/17.
//  Copyright © 2017 Lauren Wong. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
   
    var cont : Bool = false
    var opPressed : Bool = false;
    var decimal : Bool = false
    var Equals : Bool = false
    var previous : Double = 0
    var current : Double = 0
    var oldCurrent : Double = 0
    var op : String = ""
    @IBOutlet var ops: [UIButton]!
    
    @IBAction func opPressed(_ sender:
        UIButton) {
        for UIButton in  ops{
            UIButton.layer.borderWidth = 0
        }
        if (Equals){
            op = ""
            Equals = false
        }
        if (!opPressed){
         current = (Double(resultsLabel.text!))!
         switch op {
          case "+":
           resultsLabel.text = String(previous + current)
          case "-":
            resultsLabel.text = String(previous - current)
          case "x":
            resultsLabel.text = String(previous * current)
          case "/":
            resultsLabel.text = String(previous / current)

          default:
            op = ""
        }
         previous = Double(resultsLabel!.text!)!
         oldCurrent = current
         opPressed = true
         cont = false
        }
        op = sender.titleLabel!.text!
        sender.layer.borderWidth = 2
        decimal = false
        
    }
    @IBAction func numberButtonPressed(_ sender : UIButton){
        for UIButton in  ops{
            UIButton.layer.borderWidth = 0
        }
        opPressed = false;
        if(!cont){
            resultsLabel.text = sender.titleLabel?.text!
            cont = true
        }else if resultsLabel.text == "0"{
            if (sender.titleLabel?.text == "0"){
            }

            else{
            resultsLabel.text = sender.titleLabel?.text!
            }
        } else{
            resultsLabel.text = resultsLabel.text! + sender.titleLabel!.text!
        }
    }
    @IBOutlet weak var resultsLabel:
    UILabel!
    
    @IBAction func equalsPressed(_ sender: UIButton) {
        for UIButton in  ops{
            UIButton.layer.borderWidth = 0
        }
        if(Equals){
            current = oldCurrent
        }
        else{
            current = Double(resultsLabel.text!)!}
        switch op {
        case "+":
            resultsLabel.text = String(previous + current)
        case "-":
            resultsLabel.text = String(previous - current)
        case "x":
            resultsLabel.text = String(previous * current)
        case "/":
            resultsLabel.text = String(previous / current)
        default:
            op = ""
            
        }
        previous = Double(resultsLabel!.text!)!
        oldCurrent = current
        opPressed = false
        Equals = true
        cont = false
        decimal = false
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func decimalPressed(_ sender: UIButton) {
        for UIButton in  ops{
            UIButton.layer.borderWidth = 0
        }
        if(!decimal){
            if(cont){
             resultsLabel.text = resultsLabel.text! + sender.titleLabel!.text!
            
            }
            else{
                resultsLabel.text = "0."
            }
            decimal = true
            cont = true
        }
    }

    @IBAction func clearPressed(_ sender: UIButton) {
        for UIButton in  ops{
            UIButton.layer.borderWidth = 0
        }
        resultsLabel.text = "0"
        previous = 0
        op = ""
        cont = false
        decimal = false
        opPressed = false
    }
    @IBAction func signPressed(_ sender: UIButton) {
        for UIButton in  ops{
            UIButton.layer.borderWidth = 0
        }
        if (Double(resultsLabel.text!) != 0){
        let changeSign = Double(resultsLabel.text!)! * -1
         resultsLabel.text = String(changeSign)
        cont = false
        }
    }

    @IBAction func percentPressed(_ sender: UIButton) {
        for UIButton in  ops{
            UIButton.layer.borderWidth = 0
        }
        var number : Double = Double(resultsLabel.text!)!
        number = number/100
        resultsLabel.text = String(number)
    }

    @IBAction func pressed(_ sender: UIButton) {

        sender.showsTouchWhenHighlighted = true
        
    }

    
}

